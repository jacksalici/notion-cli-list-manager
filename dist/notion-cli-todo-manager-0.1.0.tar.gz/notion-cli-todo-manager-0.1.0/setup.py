# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['notion_cli_todo_manager']

package_data = \
{'': ['*']}

install_requires = \
['requests>=2.26.0,<3.0.0', 'typer>=0.4.0,<0.5.0']

entry_points = \
{'console_scripts': ['todo = notion_cli_todo_manager.main:app']}

setup_kwargs = {
    'name': 'notion-cli-todo-manager',
    'version': '0.1.0',
    'description': 'A simple line-command tool for managing a Notion ToDo Database',
    'long_description': '\n#### ⚠️ This project is still in work in progress. Changes to the commands could be done in the future.\n\n\n# Notion CLI To-Do Manager 🗂\n### Increase your productivity with a simple command. 🛋\n\nA simple line-command tool for managing [Notion](http://notion.so) databases of ___ToDo___. You can copy this (link to insert) template.\n\n\n## Syntax:\n\n| Commands:|    | Args:|\n|---|---|---|\n| `todo all` | to display all the ___ToDo___ not done yet. |    |\n| `todo add [title]` | to add a new ___ToDo___ called `title`. |   `[title]` will be the text of the ___ToDo___ (and the title of the associated Notion database page)  | \n| `todo rm [index]` | to remove the ___ToDo___ with the index `index`.  <br> (Command to call after `todo all`)| `[index]` have to be formatted either like a range and a list, or a combination of these. E.g.: 3,4,6:10:2 will remove pages 3, 4, 6, 8.\n| `todo set [token] [database_id]` | to set the token and the Notion Database ID. This must be execute as first command. | You can get the `[token]` as internal api integration here (link to insert). <br> You can get the database id from the database url: notion.so/[username]/`[database_id]`?v=[view_id].  |\n\n\n\n## Usage:\n\n1. Install the `pip` module.\n\n### Otherwise\n\n2. Clone the directory. \n\nExecute the \n\n\n\n\n## Still toDo:\n###### forgive the play on words\n\n- [ ] setter for the db id and the token\n- [ ] `rm --all` command arg\n- [ ] support for tags\n- [ ] improve the code stability\n- [ ] http requests async \n',
    'author': 'Jack Salici',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
